using System.Collections;
using System.Threading.Tasks;
using Unity.VisualScripting;
using UnityEngine;

public class PlayerInflate : MonoBehaviour
{
    [Header("Inflate Settings")]
    [SerializeField] float inflateMultiplier = 2f;
    [SerializeField] float inflateDuration = 0.25f;
    [SerializeField] float inflatedDuration = 2f;
    [SerializeField] float deflateDuration = 3f;
    [SerializeField] float inflateCooldown = 3f;
    [SerializeField] float inflateForce = 0.5f;
    [SerializeField] Collider playerHitbox;

    private Rigidbody rb;
    private Vector3 originalScale;
    private Vector3 targetScale;
    private bool isBusy = false;

    [Header("Jump / Hover Settings")]
    [SerializeField] float jumpForce = 5f;
    [SerializeField] bool applyFloat = false;

    [Header("Color Change")]
    [SerializeField] Color darkColor;
    [SerializeField] Color lightColor;
    [SerializeField] Renderer playerRenderer;
    private Material playerMaterial;

    private void Awake() {
        rb = GetComponent<Rigidbody>();

        originalScale = transform.localScale;
        targetScale = originalScale * inflateMultiplier;

        if (playerRenderer != null) {
            playerMaterial = playerRenderer.material;
            playerMaterial.color = darkColor;
        }
    }

    public void OnInflate() {
        if (isBusy)
            return;

        StartCoroutine(InflateSequence());
    }

    private IEnumerator InflateSequence()
    {
        isBusy = true;

        float _timer = 0f;

        while (_timer < inflateDuration) {
            _timer += Time.deltaTime;
            float _percent = Mathf.Clamp01(_timer / inflateDuration);

            transform.localScale = Vector3.Lerp(originalScale, targetScale, _percent);

            SetColor(Color.Lerp(darkColor, lightColor, _percent));

            PushInteractiveObjects();

            yield return null;
        }

        rb.useGravity = true;
        rb.linearVelocity = new Vector3(
            rb.linearVelocity.x,
            jumpForce,
            rb.linearVelocity.z
         );

        rb.useGravity = false;

        _timer = 0f;

        while (_timer < inflatedDuration) {
            _timer += Time.deltaTime;

            transform.localScale = targetScale;
            SetColor(lightColor);

            yield return null;
        }


        _timer = 0f;

        while (_timer < deflateDuration) {
            rb.useGravity = true;
            _timer += Time.deltaTime;
            float _percent = Mathf.Clamp01(_timer / deflateDuration);

            transform.localScale = Vector3.Lerp(targetScale, originalScale, _percent);

            SetColor(lightColor);

            yield return null;
        }

        transform.localScale = originalScale;

        _timer = 0f;

        while (_timer < inflateCooldown) {
            _timer += Time.deltaTime;
            float _percent = Mathf.Clamp01(_timer / inflateCooldown);

            SetColor(Color.Lerp(lightColor, darkColor, _percent));

            yield return null;
        }

        SetColor(darkColor);

        isBusy = false;
    }

    private void SetColor(Color _color)
    {
        if (playerMaterial == null)
            return;

        if (playerMaterial.HasProperty("_BaseColor"))
        {
            playerMaterial.SetColor("_BaseColor", _color);
        }
        else if (playerMaterial.HasProperty("_Color"))
        {
            playerMaterial.SetColor("_Color", _color);
        }
    }

    private void PushInteractiveObjects() {
        if (playerHitbox == null)
            return;

        Collider[] hits = Physics.OverlapBox(
            playerHitbox.bounds.center,
            playerHitbox.bounds.extents,
            playerHitbox.transform.rotation
         );

        foreach (Collider hit in hits) {
            if (!hit.CompareTag("Interactive"))
                continue;

            Rigidbody _objectRb = hit.attachedRigidbody;

            if (_objectRb == null || _objectRb == rb)
                continue;

            Vector3 _direction = _objectRb.worldCenterOfMass - transform.position;

            if (_direction.sqrMagnitude > 0.001f) {
                _direction.Normalize();

                _objectRb.AddForce(_direction * inflateForce, ForceMode.Impulse);
            }
        }
    }
}
