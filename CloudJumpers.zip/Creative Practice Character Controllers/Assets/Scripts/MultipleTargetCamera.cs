using UnityEngine;
using System.Collections.Generic;
using UnityEngine.Rendering.Universal;

[RequireComponent(typeof(Camera))]
public class MultipleTargetCamera : MonoBehaviour {
    [Header("Camera Targets")]
    public List<Transform> targets;

    [Header("Camera Movement")]
    public Vector3 offset;
    public float smoothTime = 0.5f;

    [Header("Camera Zoom")] 
    public float minZoom = 40f;
    public float maxZoom = 10f;
    public float zoomLimiter = 5f;

    private Vector3 velocity;
    private Camera cam;

    private void Start() {
        cam = GetComponent<Camera>();
    }

    private void LateUpdate() {
        if (targets.Count == 0) return;

        Move();
        Zoom();
    }

    void Zoom() {
        float newZoom = Mathf.Lerp(maxZoom, minZoom, GetGreatestDistance() / zoomLimiter);
        cam.fieldOfView = Mathf.Lerp(cam.fieldOfView, newZoom, Time.deltaTime);
    }

    void Move() {
        Vector3 centerPoint = GetCenterPoint();

        Vector3 newPosition = centerPoint + offset;

        transform.position = Vector3.SmoothDamp(transform.position, newPosition, ref velocity, smoothTime);
    }

    float GetGreatestDistance() {
        var bounds = new Bounds(targets[0].position, Vector3.zero);
        for (int i = 1; i < targets.Count; i++) {
            bounds.Encapsulate(targets[i].position);
        }
        return bounds.size.x;
    }

    Vector3 GetCenterPoint() {
        if (targets.Count == 1) { 
            return targets[0].position;
        }
        var bounds = new Bounds(targets[0].position, Vector3.zero);
        for (int i = 0; i < targets.Count; i++) {
            bounds.Encapsulate(targets[i].position);
        }
        return bounds.center;
    }
}
